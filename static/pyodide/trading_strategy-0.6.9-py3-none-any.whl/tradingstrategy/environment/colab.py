from tradingstrategy.environment.base import Environment
from tradingstrategy.environment.jupyter import JupyterEnvironment


class ColabEnvironment(JupyterEnvironment):

    def start(self):
        pass