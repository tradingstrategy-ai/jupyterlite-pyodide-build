from .betareg import BetaModel

__all__ = ["BetaModel"]
