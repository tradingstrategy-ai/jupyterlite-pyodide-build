from typing import (
    NewType,
)

NodeID = NewType("NodeID", bytes)
